public interface IDatosPredefinidos {
    public String mensaje1();
    public String mensaje2();
    public String mensaje3();
    public String mensaje4();
/*
 * Audrey Samantha Bhor López - 22545
    Brandon Javier Reyes Morales - 22992
    Wilson Alejandro Calderón A. - 22018
    Jose Angel Morales Farfan - 22689

 */
}
